<?php if(!defined('INCLUDE_PATH')){die('error!');};?><style>
.footer{
	border-top:1px solid #ccc;
	width:1000px;
	margin:auto;
	line-height:30px;
	font-size:14px;
	text-align:center;
	padding-top:5px;
	margin-top:10px;
}
.footer a{
	margin:0px 8px;
}
.copyright{
	font-size:12px;
	line-height:25px;
}
</style>
<div class="clear" style="clear:both"></div>
<div class="footer">
		<a href="/index.php?cid=53" target="_blank">公司简介</a>|<a href="/index.php?cid=55">招贤纳士</a>|<a href="/index.php?cid=56">广告服务</a>|<a href="/index.php?cid=57">银行汇款帐号</a>|<a href="/index.php?cid=58">联系方式</a>|<a href="/index.php?cid=59">版权声明</a>|<a href="/index.php?cid=60">注册协议</a>|<a href="#">问题报告</a>|<a href="#">合作伙伴</a>|<a href="#">论坛反馈</a>|<a href="#">网游监管</a>
		<div class="copyright">保定市筑梦聚力网络有限公司 版权所有<br>Copyright © 2015-2016, DINGD.CN, All Rights Reserved<br>冀ICP备15029663号<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1257447640'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s11.cnzz.com/z_stat.php%3Fid%3D1257447640%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script></div>
</div>
<style>
#to_top{width:30px; height:40px; padding:20px; font:14px/20px arial; text-align:center;  background:#06c; position:fixed; cursor:pointer; color:#fff;right:0px;bottom:0px;}
</style>
<script>
window.onload = function(){
  var oTop = document.getElementById("to_top");
 
  oTop.onclick = function(){
    document.documentElement.scrollTop = document.body.scrollTop =0;
  }
}  

</script>
<div id="to_top">返回顶部</div>
</body>
</html>
</html>